//
//  ViewController.m
//  xingxing
//
//  Created by develop5 on 2017/12/26.
//  Copyright © 2017年 yiqihi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<CAAnimationDelegate>
{
    CALayer  *maskLayer;
    CALayer *shineLayer;
    CAShapeLayer *shapeLayer;
    CALayer *angleLayer;
    NSMutableArray *shineLayers;
    NSMutableArray *smallShineLayers;
    CADisplayLink *displaylink;
 
}
@property(nonatomic,strong)UIButton *starBtn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.starBtn];
    NSString *strResourcesBundle = [[NSBundle mainBundle] pathForResource:@"ShineButton" ofType:@"bundle"];

    NSString *str = [[NSBundle bundleWithPath:strResourcesBundle] pathForResource:@"heart" ofType:@"png" inDirectory:@"resource"];
    maskLayer = [CALayer new];
    maskLayer.frame = self.starBtn.bounds;

    UIImage *img = [UIImage imageWithContentsOfFile:str];
    maskLayer.contents = (__bridge id)img.CGImage;


    CALayer  *layer = [CALayer new];
    layer.frame = self.starBtn.bounds;
    layer.mask = maskLayer;
    layer.backgroundColor = [UIColor lightGrayColor].CGColor;
    [self.starBtn.layer addSublayer:layer];
    
    shineLayer = [CALayer new];
    shineLayer.frame = self.starBtn.bounds;
    
    [self.starBtn.layer addSublayer:shineLayer];
    
    shapeLayer = [CAShapeLayer new];

  
    
    shapeLayer.fillColor = [UIColor clearColor].CGColor;
   
     shapeLayer.strokeColor = [UIColor yellowColor].CGColor;
     shapeLayer.lineWidth = 1.5;
    
    [shineLayer addSublayer:shapeLayer];
    

    // Do any additional setup after loading the view, typically from a nib.
}

-(UIButton *)starBtn {
    if (_starBtn == nil) {
        _starBtn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 20, 20)];
        [_starBtn addTarget:self action:@selector(startAnim) forControlEvents:UIControlEventTouchUpInside];
    }
    return _starBtn;
}
-(void)startAnim{
    CAKeyframeAnimation  *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];

    anim.duration  = 0.2;
    anim.values = @[@0.4, @1, @0.9, @1];
    anim.calculationMode = kCAAnimationCubic;
    [maskLayer addAnimation:anim forKey:@"scale"];
    
    
    CABasicAnimation *anim2 =  [CABasicAnimation   animationWithKeyPath:@"path"];
    anim2.duration = 0.2;
    CGSize size =  shineLayer.frame.size;
    UIBezierPath *fromPath = [UIBezierPath bezierPathWithArcCenter:CGPointMake(size.width/2, size.height/2) radius:1 startAngle:0 endAngle:M_PI * 2.0 clockwise:false];
   UIBezierPath *toPath = [UIBezierPath bezierPathWithArcCenter:CGPointMake(size.width/2, size.height/2) radius:size.width/2 * 1.5  startAngle:0 endAngle:M_PI * 2.0 clockwise:false];
    anim2.delegate = self;
 
    anim2.fromValue = (__bridge id _Nullable)(fromPath.CGPath);
    anim2.toValue = (__bridge id _Nullable)(toPath.CGPath);
    anim2.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    anim2.removedOnCompletion= NO;
    anim2.fillMode = kCAFillModeForwards;
    [shapeLayer addAnimation:anim2 forKey:@"path"];

}
-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    if (anim == [shapeLayer animationForKey:@"path"]) {
        [shapeLayer removeAllAnimations];
        angleLayer = [CALayer new];
        angleLayer.frame = self.starBtn.bounds;
        [shineLayer addSublayer: angleLayer];
        [self addShines];
        [self startShineAnim];
    }
    
    
}
-(void)addShines{
    shineLayers = [NSMutableArray new];
    smallShineLayers = [NSMutableArray new];
    int shineCount = 15;
    float shineDistanceMultiple = 1.5;
    CGFloat startAngle = 0.f;
    CGFloat angle = M_PI * 2.0 / shineCount + startAngle;
    CGFloat shineSize = 0.f;
    if (shineCount%2 != 0) {
        startAngle = M_PI * 2.0 - (angle / shineCount);
    }
    
    CGFloat radius = angleLayer.frame.size.width/2 * shineDistanceMultiple;
    
    for (int i = 0; i < shineCount; i++) {
        CAShapeLayer *bigShine = [CAShapeLayer new];
        
        CGFloat  bigWidth = angleLayer.frame.size.width*0.15;
        if (shineSize != 0) {
            bigWidth = shineSize;
        }
        CGPoint center = [self getShineCenter: startAngle + angle*i radius:radius];
        UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:bigWidth startAngle: 0 endAngle:M_PI * 2 clockwise:false];
        bigShine.path = path.CGPath;
        bigShine.fillColor = [UIColor colorWithRed:255/255.0 green:95/255.0 blue:89/255 alpha:1].CGColor;
        
        [angleLayer addSublayer:bigShine];
        [shineLayers addObject:bigShine];
        
        
        CGFloat smallShineOffsetAngle = 20;
        CAShapeLayer *smallShine = [CAShapeLayer new];
        CGFloat smallWidth = bigWidth*0.66;
        CGPoint smallCenter = [self getShineCenter:startAngle + angle * i -smallShineOffsetAngle * M_PI/180 radius:radius-bigWidth];
        UIBezierPath *smallPath = [UIBezierPath bezierPathWithArcCenter:smallCenter radius:smallWidth startAngle:0 endAngle:M_PI * 2.0 clockwise:false];
        smallShine.path = smallPath.CGPath;
        smallShine.fillColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1].CGColor;
        [angleLayer addSublayer:smallShine];
        [smallShineLayers addObject:smallShine];
        
    }
}

-(CGPoint )getShineCenter:(CGFloat) angle radius:(CGFloat)radius{
    CGFloat cenx = CGRectGetMidX(angleLayer.bounds);
    CGFloat ceny = CGRectGetMidY(angleLayer.bounds);
    int multiple = 0;
    if (angle >= 0 && angle <= 90 * M_PI/180) {
        multiple = 1;
    }else if (angle <= M_PI && angle > 90 * M_PI/180) {
        multiple = 2;
    }else if (angle > M_PI && angle <= 270 * M_PI/180) {
        multiple = 3;
    }else {
        multiple = 4;
    }
    
    CGFloat resultAngel = multiple*(90 * M_PI/180) - angle;
    CGFloat a = sin(resultAngel)*radius;
    CGFloat b = cos(resultAngel)*radius;
    if (multiple == 1) {
        return CGPointMake(cenx+b, ceny-a);
    }else if (multiple == 2) {
        return CGPointMake(cenx+a, ceny+b);
    }else if (multiple == 3) {
        return CGPointMake(cenx-b, ceny+a);
    }else {
        return CGPointMake(cenx-a, ceny-b);
    }
}


-(void)startShineAnim{
    int shineCount = 15;
    float shineDistanceMultiple = 1.5;
    CGFloat startAngle = 0.f;
    CGFloat shineSize = 0.f;
    CGFloat smallShineOffsetAngle = 20;
    float radius = angleLayer.frame.size.width/2 * shineDistanceMultiple*1.4;
    CGFloat angle = M_PI * 2 / shineCount + startAngle;
    if (shineCount%2 != 0) {
        startAngle = M_PI * 2.0 - (angle / shineCount);
    }
    
    for (int i = 0; i < shineCount; i++) {
        CAShapeLayer *bigShine = shineLayers[i];
        CABasicAnimation *bigAnim = [self getAngleAnim:bigShine angle:startAngle + angle * i radius:radius];
        CAShapeLayer *smallShine = smallShineLayers[i];
        CGFloat radiusSub = angleLayer.frame.size.width*0.15*0.66;
        if (shineSize !=0) {
            radiusSub = shineSize*0.66;
        }
        CABasicAnimation *smallAnim = [self getAngleAnim:smallShine angle:startAngle + angle * i - smallShineOffsetAngle * M_PI /180  radius: radius-radiusSub];
        
        [bigShine addAnimation:bigAnim forKey:@"path"];
        [smallShine addAnimation:smallAnim forKey:@"path"];
    }
    
    
    CABasicAnimation *angleAnim = [CABasicAnimation animationWithKeyPath: @"transform.rotation"];
    angleAnim.duration = 2 * 0.87;
    angleAnim.timingFunction =  [CAMediaTimingFunction functionWithName: kCAMediaTimingFunctionLinear];
    angleAnim.fromValue = @0;
    angleAnim.toValue = @(20*M_PI/180);
    angleAnim.delegate = self;
    
    [angleLayer addAnimation:angleAnim forKey:@"rotate"];
    
    
}

-(CABasicAnimation *)getAngleAnim:(CAShapeLayer *)shine angle:(CGFloat)angle radius:(CGFloat)radius{
    CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"path"];
    anim.duration = 2* 0.87;
    anim.fromValue = (__bridge id _Nullable)(shine.path);
    CGPoint center = [self getShineCenter:angle radius:radius];
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:0.1 startAngle:0 endAngle:M_PI * 2.0  clockwise:false];
    anim.toValue = (__bridge id _Nullable)(path.CGPath);
    anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    anim.removedOnCompletion = false;
    anim.fillMode = kCAFillModeForwards;
    return anim;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
